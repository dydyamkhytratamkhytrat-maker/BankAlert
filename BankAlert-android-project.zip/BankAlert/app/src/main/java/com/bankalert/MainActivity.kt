package com.bankalert

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var speaker: Speaker
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        speaker = Speaker(this)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tv(t: String, sp: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; gravity = Gravity.START
            setTextColor(Color.parseColor("#12263A"))
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 2)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        col.addView(tv("منبه لعدم الاحتيال", 26f, true))
        col.addView(tv("ينطق لك مبلغ الإشعارات البنكية بصوت عربي واضح، وينبهك إذا بدت الرسالة احتيالاً.", 16f))
        status = tv("", 17f, true)
        col.addView(status)
        col.addView(btn("تفعيل صلاحية الوصول إلى الإشعارات") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        col.addView(Switch(this).apply {
            text = "تشغيل النطق"; textSize = 18f
            isChecked = Prefs.enabled(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Prefs.setEnabled(this@MainActivity, v) }
        })

        val rateLabel = tv("", 16f)
        fun rateText(r: Float) = "سرعة الصوت: " + String.format(java.util.Locale.US, "%.2f", r)
        val r0 = Prefs.rate(this)
        rateLabel.text = rateText(r0)
        col.addView(rateLabel)
        col.addView(SeekBar(this).apply {
            max = 60 // 0.60 .. 1.20
            progress = ((r0 - 0.6f) * 100).toInt().coerceIn(0, 60)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    val r = 0.6f + p / 100f
                    Prefs.setRate(this@MainActivity, r); rateLabel.text = rateText(r)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        col.addView(btn("ضبط الصوت العربي (جوجل)") {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (e: Exception) { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
        })
        col.addView(btn("السماح بالعمل في الخلفية") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        val input = EditText(this).apply {
            hint = "الصق رسالة بنك للتجربة"; minLines = 3; gravity = Gravity.TOP or Gravity.START
        }
        col.addView(input)
        col.addView(btn("جرّب القراءة") {
            val txt = input.text.toString().ifBlank { "تم استلام تحويل بقيمة 250 MRU من محمد ولد أحمد" }
            val r = Parser.parse(txt)
            speaker.speak(if (r.isFinancial) Parser.spoken(r) else "لم أتعرف على إشعار مالي في هذا النص.")
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val on = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = if (on) "الحالة: مفعّل ويعمل" else "الحالة: غير مفعّل. اضغط الزر أدناه وفعّل التطبيق."
        status.setTextColor(Color.parseColor(if (on) "#0E8A5F" else "#B3261E"))
    }

    override fun onDestroy() { speaker.shutdown(); super.onDestroy() }
}
