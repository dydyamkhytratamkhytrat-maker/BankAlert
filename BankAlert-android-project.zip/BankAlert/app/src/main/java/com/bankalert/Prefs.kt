package com.bankalert

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("bankalert", Context.MODE_PRIVATE)
    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()
    /** speech rate, 0.6 .. 1.2 (default 0.85 = clear and not fast) */
    fun rate(c: Context) = sp(c).getFloat("rate", 0.85f)
    fun setRate(c: Context, v: Float) = sp(c).edit().putFloat("rate", v).apply()
}
