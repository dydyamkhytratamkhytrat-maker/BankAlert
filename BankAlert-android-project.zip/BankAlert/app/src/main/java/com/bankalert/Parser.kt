package com.bankalert

import kotlin.math.max
import kotlin.math.min

object Parser {
    enum class Kind { IN, OUT, UNKNOWN }
    data class Result(
        val amount: Double?, val kind: Kind, val sender: String?,
        val flags: List<String>, val isFinancial: Boolean
    )

    const val CURRENCY = "أوقية جديدة"
    private val currencyWords = listOf("أوقية", "اوقية", "MRU", "UM", "أ.م", "MRO", "ouguiya")
    private val bankWords = listOf("رصيد", "حساب", "بنك", "مصرف", "compte", "solde", "bank", "account", "virement", "banque")
    private val inWords = listOf("إيداع", "ايداع", "تم إضافة", "تمت إضافة", "اضافة", "إضافة", "وارد", "استلام", "استلمت", "وصلك", "وصل",
        "credited", "credit", "received", "deposit", "crédité", "credite", "reçu", "recu", "versement", "dépôt", "depot")
    private val outWords = listOf("خصم", "سحب", "شراء", "مدين", "صادر", "تم تحويل", "دفع",
        "debited", "debit", "purchase", "withdraw", "paid", "sent", "débité", "debite", "retrait", "paiement", "achat")
    private val stopWords = setOf("بتاريخ", "بتأريخ", "في", "على", "الى", "إلى", "الرصيد", "رصيد", "رصيدك", "عبر", "بواسطة",
        "مرجع", "المرجع", "تاريخ", "و", "ورصيدك", "date", "ref", "on", "at", "balance", "via", "عملية", "رقم")
    private val notSender = listOf("حساب", "بطاقة", "رصيد", "account", "card")
    private val bad = listOf(
        Regex("https?://|www\\.|bit\\.ly|tinyurl", RegexOption.IGNORE_CASE) to "تحتوي الرسالة على رابط. لا تضغط عليه.",
        Regex("(رمز|كود|otp|pin|الرقم السري|كلمة المرور).{0,30}(أرسل|ارسل|زودنا|شارك|اعطنا|أعطنا|send|share|envoy)", RegexOption.IGNORE_CASE) to "تطلب رمزاً سرياً. البنك لا يطلب ذلك أبداً.",
        Regex("(موقوف|معلق|تجميد|suspend|blocked|locked|bloqué)", RegexOption.IGNORE_CASE) to "تذكر تعليق الحساب. هذا أسلوب احتيال شائع.",
        Regex("(اضغط|انقر|حدّث|verify|update your|click|cliquez)", RegexOption.IGNORE_CASE) to "تطلب منك إجراءً عاجلاً. تحقق من تطبيق البنك الرسمي.",
        Regex("(ربحت|جائزة|فزت|winner|prize|gagné)", RegexOption.IGNORE_CASE) to "تعلن جائزة. غالباً احتيال."
    )
    private val numRe = Regex("""(\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)""")
    private val refRe = Regex("(رقم|مرجع|المرجع|عملية|ref|n°|no\\.?|id|حساب|account|بطاقة|card|carte|\\*\\*|xx|رصيد|solde|balance)", RegexOption.IGNORE_CASE)
    private val amtRe = Regex("(مبلغ|بمبلغ|قيمة|بقيمة|amount|montant|amt|إضافة|اضافة|إيداع|ايداع|حوالة|تحويل)", RegexOption.IGNORE_CASE)

    fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s) when (c) {
            in '٠'..'٩' -> sb.append('0' + (c - '٠'))
            in '۰'..'۹' -> sb.append('0' + (c - '۰'))
            '٫' -> sb.append('.')
            '٬' -> sb.append(',')
            else -> sb.append(c)
        }
        return sb.toString()
    }

    private fun findSender(t: String): String? {
        val tokens = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val idx = tokens.indexOfFirst { it == "من" || it.equals("from", true) }
        if (idx < 0) return null
        val out = mutableListOf<String>()
        for (k in idx + 1 until tokens.size) {
            val w = tokens[k].trim('.', ',', '،', ':', ';', '؛', '(', ')', '"')
            if (w.isEmpty() || w in stopWords || w.any { it.isDigit() } || w.contains("*")) break
            out.add(w)
            if (out.size == 4 || tokens[k].last() in ".,،;؛") break
        }
        val name = out.joinToString(" ")
        if (name.length < 2 || notSender.any { name.startsWith(it) }) return null
        return name
    }

    fun parse(raw: String): Result {
        val t = normalize(raw)
        var best: Pair<Double, Int>? = null
        var curFound = false
        for (m in numRe.findAll(t)) {
            val digits = m.value.count { it.isDigit() }
            if (digits >= 9 && !m.value.contains('.')) continue // account / phone / reference numbers
            val v = m.value.replace(",", "").toDoubleOrNull() ?: continue
            val s0 = max(0, m.range.first - 25)
            val before = t.substring(s0, m.range.first)
            val around = t.substring(s0, min(t.length, m.range.last + 15))
            var score = 0
            if (amtRe.containsMatchIn(before)) score += 2
            if (currencyWords.any { around.contains(it, ignoreCase = true) }) { score += 2; curFound = true }
            if (refRe.containsMatchIn(t.substring(max(0, m.range.first - 14), m.range.first))) score -= 3
            if (Regex("^\\d{1,2}[:/]\\d{1,2}").containsMatchIn(t.substring(m.range.first, min(t.length, m.range.first + 8)))) score -= 3
            if (best == null || score > best.second) best = v to score
        }
        val amount = best?.takeIf { it.second >= 0 }?.first
        val low = t.lowercase()
        val i = inWords.count { low.contains(it.lowercase()) }
        val o = outWords.count { low.contains(it.lowercase()) }
        val kind = if (i > o) Kind.IN else if (o > i) Kind.OUT else Kind.UNKNOWN
        val flags = bad.filter { it.first.containsMatchIn(t) }.map { it.second }
        val bankish = bankWords.any { low.contains(it.lowercase()) }
        val financial = curFound || (bankish && kind != Kind.UNKNOWN)
        val sender = if (kind == Kind.IN) findSender(t) else null
        return Result(amount, kind, sender, flags, financial)
    }

    private fun amountText(a: Double): String =
        if (a % 1.0 == 0.0) a.toLong().toString() else String.format(java.util.Locale.US, "%.2f", a)

    fun spoken(r: Result): String {
        val parts = mutableListOf<String>()
        if (r.flags.isNotEmpty()) parts.add("تنبيه. هذه الرسالة تبدو مشبوهة. ${r.flags[0]}")
        if (r.amount == null) {
            parts.add("وصل إشعار مالي جديد.")
        } else {
            val a = amountText(r.amount)
            parts.add(when (r.kind) {
                Kind.IN -> "تم استلام $a $CURRENCY" + (r.sender?.let { " من $it" } ?: "") + "."
                Kind.OUT -> "تم خصم $a $CURRENCY."
                else -> "وصل إشعار مالي بمبلغ $a $CURRENCY."
            })
        }
        return parts.joinToString(" ")
    }
}
