package com.bankalert

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Speaker(context: Context) {
    private val ctx = context.applicationContext
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private var focus: AudioFocusRequest? = null
    private var ready = false
    private var pending: String? = null
    private var tts: TextToSpeech = create(true)

    private fun create(google: Boolean): TextToSpeech {
        val listener = TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                setup()
                ready = true
                pending?.let { speak(it); pending = null }
            } else if (google) {
                tts = create(false) // Google engine missing: use the phone's default engine
            }
        }
        return if (google) TextToSpeech(ctx, listener, "com.google.android.tts")
        else TextToSpeech(ctx, listener)
    }

    private fun setup() {
        tts.language = Locale("ar")
        try {
            val v = tts.voices
                ?.filter { it.locale.language == "ar" }
                ?.sortedWith(compareBy({ -it.quality }, { it.isNetworkConnectionRequired }))
                ?.firstOrNull()
            if (v != null) tts.voice = v
        } catch (_: Exception) {}
        tts.setAudioAttributes(attrs)
        tts.setPitch(1.0f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { release() }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { release() }
        })
    }

    private fun release() {
        focus?.let { am.abandonAudioFocusRequest(it) }
        focus = null
    }

    fun speak(text: String) {
        if (!ready) { pending = text; return }
        tts.setSpeechRate(Prefs.rate(ctx))
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs).build()
        am.requestAudioFocus(req)
        focus = req
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "alert")
    }

    fun shutdown() { release(); tts.stop(); tts.shutdown() }
}
