package com.bankalert

import android.app.Notification
import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BankNotificationService : NotificationListenerService() {
    private lateinit var speaker: Speaker
    private val seen = LinkedHashMap<String, Long>()

    override fun onCreate() {
        super.onCreate()
        speaker = Speaker(this)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        requestRebind(ComponentName(this, BankNotificationService::class.java))
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.enabled(this)) return
        if (sbn.packageName == packageName) return
        if (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val ex = sbn.notification.extras
        val body = ex.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val full = "$title $body"
        val r = Parser.parse(full)
        if (!r.isFinancial) return

        // never read the same notification twice (updates / re-posts), 10-minute memory
        val key = sbn.packageName + "|" + full.hashCode()
        val now = System.currentTimeMillis()
        seen.entries.removeAll { now - it.value > 600_000 }
        if (seen.containsKey(key)) return
        seen[key] = now
        while (seen.size > 100) seen.remove(seen.keys.first())

        speaker.speak(Parser.spoken(r))
    }
}
