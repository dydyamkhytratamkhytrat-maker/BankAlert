# منبه لعدم الاحتيال (Bank Alert)

تطبيق أندرويد أصلي (Kotlin + Gradle). يقرأ الإشعارات المالية وينطق المبلغ بالعربية بالأوقية الجديدة.

## بناء APK
- **GitHub Actions:** ارفع المجلد كله إلى مستودع GitHub، ثم Actions ← Build APK ← Run workflow. ستجد الملف في Artifacts باسم `BankAlert-debug-apk`.
- **Android Studio:** Open ← اختر هذا المجلد ← Build ← Build APK(s).
- **سطر الأوامر:** `gradle :app:assembleDebug` (Gradle 8.7، JDK 17).

ملاحظة: ملف `gradle/wrapper/gradle-wrapper.jar` الثنائي غير مضمّن. لتوليده نفّذ مرة واحدة: `gradle wrapper --gradle-version 8.7`. الـ workflow لا يحتاجه.

## التفعيل على الهاتف
الإعدادات ← إمكانية وصول مميزة ← الوصول إلى الإشعارات ← منبه لعدم الاحتيال.
